﻿using Dominio;
using Microsoft.EntityFrameworkCore;
using Repositorio;
using System.Linq;
using System.Windows;
using UI.Model;


namespace UI
{
    public partial class Principal : Window
    {
        public Principal(string usuarioAtual)
        {
            InitializeComponent();

            BoxUsuarioAtual.Text = usuarioAtual;
        }

        private void BtnCadastroProduto(object sender, RoutedEventArgs e)
        {
            NovoProduto novoProduto = new NovoProduto();

            novoProduto.ShowDialog();
        }

        private void btnEditarProduto(object sender, RoutedEventArgs e)
        {
            Produto produto = (Produto)gridProdutos.SelectedItem;

            if (produto != null)
            {
                NovoProduto novoProduto = new NovoProduto(produto);

                novoProduto.ShowDialog();
            }
            else
            {
                MessageBox.Show("Selecione um item");
            }
        }

        private async void BtnConsultarProduto(object sender, RoutedEventArgs e)
        {
            ProdutoModel _pModel = new ProdutoModel();
            gridProdutos.ItemsSource = await _pModel.ListarProdutos();
        }

        private void BtnNovaVendaDialog(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Deseja incluir nome e cpf do cliente?", "Nome e CPF do Cliente", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            switch (result)
            {
                case MessageBoxResult.Yes:
                    NomeCpf nomeCpf = new NomeCpf();
                    nomeCpf.ShowDialog();
                    break;

                case MessageBoxResult.No:
                    NovaVenda novaVenda = new NovaVenda("Não informado", "Não informado");
                    novaVenda.ShowDialog();
                    break;
            }

        }

        private async void BtnConsultarVenda(object sender, RoutedEventArgs e)
        {
            VendaModel _vModel = new VendaModel();

            gridVendas.ItemsSource = await _vModel.ListarVendas();
        }

        private void BtnFecharSistema(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnExcluir(object sender, RoutedEventArgs e)
        {
            if (gridVendas.SelectedItem == null)
            {
                MessageBox.Show("Selecione uma venda para excluir");
                return;
            }

            var vendaselecionada = (Venda)gridVendas.SelectedItem;

            var confirmacao = MessageBox.Show(
                "Tem certeza que deseja excluir esta venda?",
                "Confirmar Exclusão",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (confirmacao != MessageBoxResult.Yes)
                return;

            using (var context = new Context())
            {
                var venda = context.Vendas
                    .Include(v => v.VendaProdutos)
                    .FirstOrDefault(v => v.Id == vendaselecionada.Id);

                if (venda != null)
                {
                    context.VendaProdutos.RemoveRange(venda.VendaProdutos);
                    context.Vendas.Remove(venda);

                    context.SaveChanges();
                }
            }

            MessageBox.Show("Venda excluída com sucesso!");
        }
        }
    }

